package com.bper.dghub.controlglossariservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControlGlossariServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
