package com.upload.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
//@EnableFeignClients("com.bper.dghub.controlglossariservice")
//@EnableDiscoveryClient
public class ControlGlossariServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ControlGlossariServiceApplication.class, args);
	}

}
