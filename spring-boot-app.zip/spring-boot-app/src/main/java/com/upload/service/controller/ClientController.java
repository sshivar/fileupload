package com.upload.service.controller;

import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.MediaType;
import org.springframework.http.client.MultipartBodyBuilder;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import com.upload.service.model.User;

@RestController
public class ClientController {

	@GetMapping("/getUser")
	public User getUser() {
		return new User("123","ControlGlossary","***");
	}
	
	@PostMapping(path="/getUserPost",consumes="application/json",produces="application/json")
	public User getUserPost(@RequestBody User user) {
		System.out.println("******************ControlGlossary*********************");
		System.out.println(user.getFirstName());
		System.out.println(user.getLastName());
		return new User("123","ControlGlossary","***");
	}
	
	@Autowired
    private WebClient.Builder webClientBuilder; 

    @GetMapping(value = "/client")
    public void upload() {
        final WebClient webClient = webClientBuilder.build();
        webClient.post()
                .uri("http://localhost:8080/fileUpload/upload")
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(fromFile(new File("Readme.txt"))))
                .retrieve()
                .bodyToMono(String.class)   
                .block();   
    }

    public MultiValueMap<String, HttpEntity<?>> fromFile(File file) {
        MultipartBodyBuilder builder = new MultipartBodyBuilder();
        builder.part("file", new FileSystemResource(file));
        return builder.build();
    }
}
