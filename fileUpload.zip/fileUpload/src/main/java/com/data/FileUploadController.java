package com.data;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@CrossOrigin
@RestController
public class FileUploadController {
	private File uploadDirRoot;
	
	 @Autowired
	 FileUploadController() {
	        this.uploadDirRoot = new File("C:\\DGHUB_NEW\\Angular\\wave1_merge\\fileUpload");
	    }

	@PostMapping("/upload")
	public String handleFileUpload(@RequestParam("file") MultipartFile file) {
		System.out.println("FileName:- " + file.getOriginalFilename());
		File destinationFile = new File(this.uploadDirRoot, file.getOriginalFilename());
		try (InputStream in = file.getInputStream(); OutputStream out = new FileOutputStream(destinationFile)) {
			FileCopyUtils.copy(in, out);
		} catch (IOException ex) {
			throw new RuntimeException(ex);
		}

		System.out.println("FileName:- " + file.getName());
		System.out.println("FileSize:- " + file.getSize());
		System.out.println("Uploaded   ************");
		return "Success";
	}

	@GetMapping("/getupload")
	public String getupload() {
		System.out.println("Get Call   ************");
		return "Success";
	}

	
}
